
import React, { useState } from 'react';
import { ShapeType, GestureMode, SystemStatus } from '../types';
import { SHAPES, ICONS } from '../constants.tsx';

interface OverlayUIProps {
  currentShape: ShapeType;
  onShapeChange: (shape: ShapeType) => void;
  currentColor: string;
  onColorChange: (color: string) => void;
  gestureMode: GestureMode;
  status: SystemStatus;
  onToggleFullScreen: () => void;
}

const OverlayUI: React.FC<OverlayUIProps> = ({
  currentShape,
  onShapeChange,
  currentColor,
  onColorChange,
  gestureMode,
  status,
  onToggleFullScreen
}) => {
  const [showCopied, setShowCopied] = useState(false);

  const handleShare = async () => {
    const shareData = {
      title: 'Particle Vision Pro v2.1',
      text: 'Check out this amazing 3D particle hand-gesture interaction system!',
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.log('Share failed:', err);
      }
    } else {
      // Fallback: Copy to clipboard
      try {
        await navigator.clipboard.writeText(window.location.href);
        setShowCopied(true);
        setTimeout(() => setShowCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy: ', err);
      }
    }
  };

  return (
    <div className="absolute inset-0 pointer-events-none z-10 p-6 flex flex-col justify-between overflow-hidden">
      {/* Top Header */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 p-5 rounded-3xl shadow-2xl transition-all hover:scale-[1.02]">
          <h1 className="text-white text-2xl font-bold tracking-tight mb-2 flex items-center gap-2">
            Particle Vision <span className="text-[10px] text-cyan-400 border border-cyan-400/30 px-1.5 py-0.5 rounded leading-none">V2.1</span>
          </h1>
          <div className="flex items-center gap-2.5 bg-black/40 rounded-full px-3 py-1.5 w-fit border border-white/5">
            <div className={`w-2.5 h-2.5 rounded-full transition-all duration-700 ${status.online ? 'bg-cyan-400 shadow-[0_0_12px_#22d3ee]' : 'bg-red-500 animate-pulse shadow-[0_0_10px_red]'}`} />
            <span className={`text-[10px] font-mono uppercase tracking-widest ${status.online ? 'text-cyan-300' : 'text-gray-400'}`}>
              {status.online ? 'Core Linked' : 'Searching Signal'}
            </span>
          </div>
          
          <div className="mt-4 border-t border-white/5 pt-3 flex flex-col gap-2">
             <ModeHint active={gestureMode === GestureMode.SCALE} icon="👋" text="Omni-Expansion (Scale)" />
             <ModeHint active={gestureMode === GestureMode.ROTATE} icon="☝️" text="Orbital Slide (Rotate)" />
             <ModeHint active={gestureMode === GestureMode.ROLL} icon="✌️" text="Axial Twist (Roll)" />
          </div>
        </div>

        <div className="flex gap-3">
          <div className="relative">
            <button 
              onClick={handleShare}
              className="bg-black/40 backdrop-blur-md border border-white/10 p-4 text-white hover:text-cyan-400 rounded-full transition-all hover:scale-110 active:scale-95 group pointer-events-auto relative"
            >
              <ICONS.Share />
            </button>
            {showCopied && (
              <div className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-cyan-500 text-black text-[10px] font-bold px-2 py-1 rounded shadow-lg animate-bounce">
                LINK COPIED
              </div>
            )}
          </div>

          <button 
            onClick={onToggleFullScreen}
            className="bg-black/40 backdrop-blur-md border border-white/10 p-4 text-white hover:text-cyan-400 rounded-full transition-all hover:scale-110 active:scale-95 group pointer-events-auto"
          >
            <ICONS.FullScreen />
          </button>
        </div>
      </div>

      {/* Bottom Controls */}
      <div className="flex flex-col md:flex-row gap-4 items-end md:items-center justify-between pointer-events-auto">
        <div className="bg-black/40 backdrop-blur-xl border border-white/10 p-2 rounded-2xl flex gap-1.5 overflow-x-auto max-w-full custom-scroll">
          {SHAPES.map((shape) => (
            <button
              key={shape.id}
              onClick={() => onShapeChange(shape.id)}
              className={`px-5 py-3 rounded-xl text-xs font-bold uppercase tracking-widest whitespace-nowrap transition-all ${
                currentShape === shape.id 
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-[0_0_20px_rgba(34,211,238,0.2)]' 
                : 'text-white/60 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              {shape.name}
            </button>
          ))}
        </div>

        <div className="bg-black/40 backdrop-blur-xl border border-white/10 p-4 rounded-2xl flex items-center gap-4">
          <span className="text-white/50 text-[10px] font-mono uppercase tracking-widest">Spectral Shift</span>
          <div className="relative w-10 h-10 rounded-full overflow-hidden ring-2 ring-white/10 hover:ring-cyan-400/50 transition-all cursor-pointer">
            <input 
              type="color" 
              value={currentColor}
              onChange={(e) => onColorChange(e.target.value)}
              className="absolute -top-[50%] -left-[50%] w-[200%] h-[200%] cursor-pointer border-0 p-0 m-0"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

const ModeHint: React.FC<{ active: boolean; icon: string; text: string }> = ({ active, icon, text }) => (
  <div className={`flex items-center gap-2 transition-all duration-300 ${active ? 'opacity-100 scale-105' : 'opacity-30 grayscale'}`}>
    <span className="text-sm">{icon}</span>
    <span className={`text-[9px] font-mono tracking-wider ${active ? 'text-cyan-400 font-bold' : 'text-white'}`}>{text}</span>
  </div>
);

export default OverlayUI;
