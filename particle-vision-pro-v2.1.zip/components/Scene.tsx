
import React, { useEffect, useRef, useCallback } from 'react';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { ShapeType, HandData } from '../types';
import { getShapePositions, getShapeColors, createParticleTexture } from '../services/particleService';
import { PARTICLE_COUNT, PARTICLE_SIZE } from '../constants.tsx';

interface SceneProps {
  currentShape: ShapeType;
  baseColor: string;
  handData: HandData;
}

const Scene: React.FC<SceneProps> = ({ currentShape, baseColor, handData }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const composerRef = useRef<EffectComposer | null>(null);
  const particlesRef = useRef<THREE.Points | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const clockRef = useRef(new THREE.Clock());

  const targetPositionsRef = useRef<Float32Array>(getShapePositions(currentShape));
  const targetColorsRef = useRef<Float32Array>(getShapeColors(currentShape));
  const currentShapeRef = useRef<ShapeType>(currentShape);

  // Initialize Scene
  useEffect(() => {
    if (!containerRef.current) return;

    // Setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020205, 0.02);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 30;
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: false, alpha: true, powerPreference: "high-performance" });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.toneMapping = THREE.ReinhardToneMapping;
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.autoRotate = true;
    controls.autoRotateSpeed = 0.5;
    controlsRef.current = controls;

    // Particles
    const geometry = new THREE.BufferGeometry();
    const initialPos = getShapePositions(currentShape);
    const initialCol = getShapeColors(currentShape);
    geometry.setAttribute('position', new THREE.BufferAttribute(initialPos, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(initialCol, 3));

    const material = new THREE.PointsMaterial({
      size: PARTICLE_SIZE,
      map: createParticleTexture(),
      color: new THREE.Color(baseColor),
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      sizeAttenuation: true,
      vertexColors: true
    });

    const particles = new THREE.Points(geometry, material);
    scene.add(particles);
    particlesRef.current = particles;

    // Post processing
    const composer = new EffectComposer(renderer);
    composer.addPass(new RenderPass(scene, camera));
    const bloomPass = new UnrealBloomPass(new THREE.Vector2(window.innerWidth, window.innerHeight), 1.5, 0.4, 0.85);
    bloomPass.threshold = 0.05;
    bloomPass.strength = 1.4;
    bloomPass.radius = 0.6;
    composer.addPass(bloomPass);
    composerRef.current = composer;

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      composer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    // Animation Loop
    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);
      const time = clockRef.current.getElapsedTime();
      
      if (particlesRef.current && cameraRef.current) {
        const positions = particlesRef.current.geometry.attributes.position.array as Float32Array;
        const colors = particlesRef.current.geometry.attributes.color.array as Float32Array;
        
        let targetScaleBase = 1.0;
        let targetParticleSize = PARTICLE_SIZE;
        let turbulence = 0.05;

        if (handData.isDetected) {
          targetScaleBase = 0.2 + (handData.influence * 2.3);
          turbulence = 0.02 + (handData.influence * 0.3);
          targetParticleSize = PARTICLE_SIZE * (0.8 + handData.influence * 2.5);
          controls.autoRotate = false;
        } else {
          targetScaleBase = 1.0 + Math.sin(time * 1.5) * 0.05;
          targetParticleSize = PARTICLE_SIZE * (1.0 + Math.sin(time * 1.5) * 0.15);
          controls.autoRotate = true;
          controls.autoRotateSpeed = 1.0;
        }

        // Update Material
        (particlesRef.current.material as THREE.PointsMaterial).size = THREE.MathUtils.lerp(
          (particlesRef.current.material as THREE.PointsMaterial).size, 
          targetParticleSize, 0.1
        );

        // Apply Hand Rotations
        const camRight = new THREE.Vector3(1, 0, 0).applyQuaternion(cameraRef.current.quaternion).normalize();
        const camUp = new THREE.Vector3(0, 1, 0).applyQuaternion(cameraRef.current.quaternion).normalize();
        const camForward = new THREE.Vector3(0, 0, -1).applyQuaternion(cameraRef.current.quaternion).normalize();

        particlesRef.current.rotateOnWorldAxis(camUp, handData.rotationVelocity.y);
        particlesRef.current.rotateOnWorldAxis(camRight, handData.rotationVelocity.x);
        particlesRef.current.rotateOnWorldAxis(camForward, handData.rotationVelocity.z);

        // Morph particles
        const lerpSpeed = 0.06;
        const colorLerpSpeed = 0.03;

        for (let i = 0; i < PARTICLE_COUNT; i++) {
          const idx = i * 3;
          let tx = targetPositionsRef.current[idx];
          let ty = targetPositionsRef.current[idx + 1];
          let tz = targetPositionsRef.current[idx + 2];

          const dist = Math.sqrt(tx * tx + ty * ty + tz * tz);
          const normalizedDist = Math.min(dist / 20.0, 1.0);
          
          const expansion = handData.isDetected ? 1.0 + (handData.influence * Math.pow(normalizedDist, 1.5) * 2.0) : 1.0;
          const finalScale = targetScaleBase * expansion;
          
          tx *= finalScale; ty *= finalScale; tz *= finalScale;

          if (currentShapeRef.current === 'galaxy') {
            const angle = time * (0.1 + (1.0 - (Math.sqrt(tx*tx+tz*tz)/20)) * 0.5);
            const cos = Math.cos(angle); const sin = Math.sin(angle);
            const rx = tx * cos - tz * sin;
            const rz = tx * sin + tz * cos;
            tx = rx; tz = rz;
          } else if (currentShapeRef.current === 'lotus') {
            ty += Math.sin(time + tx) * 0.5;
          } else {
            tx += Math.sin(time * 2 + i) * turbulence;
            ty += Math.cos(time * 3 + i) * turbulence;
            tz += Math.sin(time * 4 + i) * turbulence;
          }

          positions[idx] += (tx - positions[idx]) * lerpSpeed;
          positions[idx+1] += (ty - positions[idx+1]) * lerpSpeed;
          positions[idx+2] += (tz - positions[idx+2]) * lerpSpeed;

          colors[idx] += (targetColorsRef.current[idx] - colors[idx]) * colorLerpSpeed;
          colors[idx+1] += (targetColorsRef.current[idx+1] - colors[idx+1]) * colorLerpSpeed;
          colors[idx+2] += (targetColorsRef.current[idx+2] - colors[idx+2]) * colorLerpSpeed;
        }

        particlesRef.current.geometry.attributes.position.needsUpdate = true;
        particlesRef.current.geometry.attributes.color.needsUpdate = true;
      }

      controls.update();
      composer.render();
    };
    animate();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      geometry.dispose();
      material.dispose();
    };
  }, []); // Only on mount

  // Handle Shape Updates
  useEffect(() => {
    currentShapeRef.current = currentShape;
    targetPositionsRef.current = getShapePositions(currentShape);
    targetColorsRef.current = getShapeColors(currentShape);
    
    if (particlesRef.current) {
        const targetColor = currentShape === 'saturn' ? new THREE.Color(0xffffff) : new THREE.Color(baseColor);
        (particlesRef.current.material as THREE.PointsMaterial).color.copy(targetColor);
    }
  }, [currentShape, baseColor]);

  return <div ref={containerRef} className="absolute inset-0 z-0 bg-black" />;
};

export default Scene;
