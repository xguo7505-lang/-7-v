
import * as THREE from 'three';
import { PARTICLE_COUNT, SATURN_BODY_RATIO } from '../constants.tsx';
import { ShapeType } from '../types';

export function getShapePositions(type: ShapeType): Float32Array {
  const pos = new Float32Array(PARTICLE_COUNT * 3);
  
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    let x = 0, y = 0, z = 0;
    
    if (type === 'sphere') {
      const r = 10 + Math.random() * 2;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      x = r * Math.sin(phi) * Math.cos(theta);
      y = r * Math.sin(phi) * Math.sin(theta);
      z = r * Math.cos(phi);
      if (i < PARTICLE_COUNT * 0.2) { x *= 0.3; y *= 0.3; z *= 0.3; }
    } 
    else if (type === 'heart') {
      const t = Math.PI - 2 * Math.PI * Math.random();
      const u = 2 * Math.PI * Math.random();
      x = 16 * Math.pow(Math.sin(t), 3);
      y = 13 * Math.cos(t) - 5 * Math.cos(2*t) - 2 * Math.cos(3*t) - Math.cos(4*t);
      z = 6 * Math.cos(t) * Math.sin(u) * Math.sin(t);
      const scale = 0.6;
      x *= scale; y *= scale; z *= scale;
      if (Math.random() > 0.8) { x *= 1.1; y *= 1.1; z *= 1.1; }
    } 
    else if (type === 'saturn') {
      if (i < PARTICLE_COUNT * SATURN_BODY_RATIO) {
        const r = 5.5;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.acos(2 * Math.random() - 1);
        x = r * Math.sin(phi) * Math.cos(theta);
        y = r * 0.9 * Math.sin(phi) * Math.sin(theta);
        z = r * Math.cos(phi);
      } else {
        const angle = Math.random() * Math.PI * 2;
        const ringSelector = Math.random();
        let r, thickness;
        if (ringSelector < 0.45) {
          r = 7 + Math.random() * 3.5; thickness = 0.2;
        } else if (ringSelector < 0.5) {
          r = 10.5 + Math.random() * 1.5; thickness = 0.1;
          if (Math.random() > 0.2) { x=0; y=0; z=0; pos[i*3]=x; pos[i*3+1]=y; pos[i*3+2]=z; continue; }
        } else {
          r = 12 + Math.random() * 5; thickness = 0.4;
        }
        r += (Math.random() - 0.5) * 0.3;
        x = r * Math.cos(angle);
        y = (Math.random() - 0.5) * thickness;
        z = r * Math.sin(angle);
        const tilt = 0.4;
        const y_new = y * Math.cos(tilt) - x * Math.sin(tilt);
        const x_new = y * Math.sin(tilt) + x * Math.cos(tilt);
        x = x_new; y = y_new;
      }
    }
    else if (type === 'lotus') {
      const u = Math.random() * Math.PI * 2;
      const v = Math.random();
      const petals = 7;
      const rBase = 8 * (0.5 + 0.5 * Math.pow(Math.sin(petals * u * 0.5), 2)) * v;
      x = rBase * Math.cos(u);
      z = rBase * Math.sin(u);
      y = 4 * Math.pow(v, 2) - 2;
      if (i < PARTICLE_COUNT * 0.15) { x = (Math.random()-0.5); z = (Math.random()-0.5); y = (Math.random()-0.5)*10; }
    }
    else if (type === 'galaxy') {
      const arms = 3;
      const spin = i % arms;
      const angleOffset = (spin / arms) * Math.PI * 2;
      const dist = Math.pow(Math.random(), 0.5);
      const r = dist * 20;
      const angle = dist * 10 + angleOffset;
      x = r * Math.cos(angle);
      z = r * Math.sin(angle);
      y = (Math.random() - 0.5) * (15 - r) * 0.2;
      if (r < 2) y *= 0.2;
    }

    pos[i * 3] = x;
    pos[i * 3 + 1] = y;
    pos[i * 3 + 2] = z;
  }
  return pos;
}

export function getShapeColors(type: ShapeType): Float32Array {
  const cols = new Float32Array(PARTICLE_COUNT * 3);
  
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    let brightness = 0.2 + Math.random() * 0.8;
    let r, g, b;

    if (type === 'saturn') {
      if (i < PARTICLE_COUNT * SATURN_BODY_RATIO) {
        r = 1.0; g = 0.7; b = 0.3;
      } else {
        r = 0.6; g = 0.8; b = 1.0;
      }
      r *= brightness; g *= brightness; b *= brightness;
    } else {
      r = brightness; g = brightness; b = brightness;
    }

    cols[i * 3] = r;
    cols[i * 3 + 1] = g;
    cols[i * 3 + 2] = b;
  }
  return cols;
}

export function createParticleTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 32; canvas.height = 32;
  const context = canvas.getContext('2d')!;
  const gradient = context.createRadialGradient(16, 16, 0, 16, 16, 16);
  gradient.addColorStop(0, 'rgba(255,255,255,1)');
  gradient.addColorStop(0.4, 'rgba(255,255,255,0.5)');
  gradient.addColorStop(1, 'rgba(0,0,0,0)');
  context.fillStyle = gradient;
  context.fillRect(0, 0, 32, 32);
  return new THREE.CanvasTexture(canvas);
}
