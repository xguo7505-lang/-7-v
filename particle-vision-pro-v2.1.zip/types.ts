
export type ShapeType = 'sphere' | 'heart' | 'saturn' | 'lotus' | 'galaxy';

export enum GestureMode {
  SCALE = 'scale',
  ROTATE = 'rotate',
  ROLL = 'roll',
  NONE = 'none'
}

export interface HandData {
  isDetected: boolean;
  influence: number;
  mode: GestureMode;
  rotationVelocity: { x: number; y: number; z: number };
}

export interface SystemStatus {
  online: boolean;
  lastUpdate: number;
}
